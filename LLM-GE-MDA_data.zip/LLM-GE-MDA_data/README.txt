LLM-GE-MDA Data and Model Inputs

Title:
Data and semantic representations for LLM-GE-MDA:
A Large Language Model-Enhanced Graph Ensemble Learning Framework
for Microbe-Disease Association Prediction

1. Datasets

This archive contains the processed model inputs used for
microbe-disease association prediction experiments on HMDAD and Peryton.

Peryton:
- 1,396 microbes
- 43 diseases
- 4,172 nonredundant microbe-disease associations

HMDAD:
- 292 microbes
- 39 diseases
- 450 nonredundant microbe-disease associations

2. Peryton files

association_matrix.csv
Binary microbe-disease association matrix used as the structural input.

high_np_peryton_microbe_emb_1536.pkl
Entity-indexed 1536-dimensional semantic representations for microbes.

high_np_peryton_dis_emb_1536.pkl
Entity-indexed 1536-dimensional semantic representations for diseases.

3. HMDAD files

association_matrix.csv
Binary microbe-disease association matrix used in the HMDAD experiments.

high_hmdad_microbe_emb_1536.pkl
Entity-indexed 1536-dimensional semantic representations for microbes.

high_hmdad_dis_emb_1536.pkl
Entity-indexed 1536-dimensional semantic representations for diseases.

4. Prompt templates

The prompts directory contains the structured zero-shot prompt templates
used to generate biomedical descriptions for microbe and disease entities.

5. Software environment

Python 3.8.10
PyTorch 1.12.0+cpu
PyTorch Geometric 2.6.1
NumPy 1.24.4
pandas 2.0.3
scikit-learn 1.3.2
OpenAI Python SDK 2.2.0

Operating system:
64-bit Windows environment

Computation:
CPU-only; CUDA was not used.

Random seed:
42

6. Original data sources

HMDAD:
http://www.cuilab.cn/hmdad

Peryton:
https://dianalab.e-ce.uth.gr/peryton/

7. Notes

Known associations are encoded as 1 in the association matrices.
Zero entries indicate unrecorded candidate pairs and should not be
interpreted as experimentally confirmed negative associations.

The semantic embedding files are aligned with the entity order used
in the corresponding association matrices.